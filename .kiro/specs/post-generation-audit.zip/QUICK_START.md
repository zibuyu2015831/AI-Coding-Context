---
title: 文档体系生成后自动审核机制 - 快速开始
summary: 为AI提供快速上手指南，包含需求概述、核心任务、实现步骤和关键上下文，确保AI能立即开始开发
keywords: 快速开始 | 开发指南 | 审核机制 | 实现步骤
scope: 开发任务快速参考
related_files: requirements.md
verified_at: 2025-12-19
---

# 文档体系生成后自动审核机制 - 快速开始

> **面向**: AI开发助手  
> **阅读时间**: 3分钟  
> **目标**: 快速理解任务并开始开发

---

## 🎯 任务概述

**需求**: 建立一个自动化的文档体系审核机制

**触发时机**: 用户使用框架完成文档体系搭建后

**核心目标**: 自动检查生成的文档是否符合框架标准，生成审核报告

**优先级**: P0 (最高优先级)

---

## 🔍 为什么需要这个功能？

### 实际问题（来自002案例）

在002案例中，我们发现了**11个遗漏项**：

**方案文档遗漏** (8个):
1. ❌ 进度记录机制 - 完全遗漏
2. ⚠️ 文档摘要规范 - 未明确要求
3. ❌ AI_RULES生成 - 完全遗漏
4. ⚠️ 数据验证命令 - 部分缺失
5. ❌ 偏离处理机制 - 完全遗漏
6. 其他...

**主文档缺失** (3个):
1. ❌ 文档维护触发器
2. ❌ AI 编码禁忌
3. ❌ 常见任务速查

### 根本原因

**框架依赖AI的"自觉性"，缺少强制检查机制**

### 解决方案

**建立自动化审核机制**，在文档生成后立即检查，确保质量。

---

## 🛠️ 核心任务

### 任务1: 创建审核工具 (3天)

#### 1.1 审核编排器
- **文件**: `tools/py/post_generation_audit.py`
- **功能**: 协调所有审核工具的执行
- **输入**: 文档目录路径
- **输出**: 审核报告

#### 1.2 方案文档审核器
- **文件**: `tools/py/audit_generation_plan.py`
- **功能**: 检查 generation_plan.md 的完整性
- **检查项**: 7个必需章节 + 内容完整性

#### 1.3 主文档审核器
- **文件**: `tools/py/audit_main_doc.py`
- **功能**: 检查 AI_Coding_Context.md 的质量
- **检查项**: 16个必需章节 + YAML摘要

#### 1.4 子文档审核器
- **文件**: `tools/py/audit_sub_docs.py`
- **功能**: 批量检查所有子文档
- **检查项**: YAML摘要完整性

#### 1.5 报告生成器
- **文件**: `tools/py/generate_audit_report.py`
- **功能**: 生成详细的审核报告
- **输出**: `dev_docs/_analysis/post_generation_audit.md`

### 任务2: 工作流集成 (1天)

#### 2.1 更新工作流
- **文件**: `workflows/path_a_first_generation.md`
- **修改**: 添加 Step 9: 文档体系审核

#### 2.2 更新工具文档
- **文件**: `tools/README.md`
- **修改**: 添加审核工具说明

#### 2.3 更新检查清单
- **文件**: `workflows/shared/ai_checklist.md`
- **修改**: 添加审核相关检查项

### 任务3: 测试和文档 (1天)

#### 3.1 编写测试
- **文件**: `tools/py/tests/test_post_generation_audit.py`
- **覆盖**: 所有审核工具

#### 3.2 使用002案例测试
- **测试数据**: `dev/real_case/002/`
- **验证**: 能检测出所有11个遗漏项

#### 3.3 编写使用文档
- **文件**: `tools/py/README_AUDIT.md`
- **内容**: 审核工具使用指南

---

## 📋 必需检查项清单

### 方案文档 (generation_plan.md)

**必需章节** (7个):
- [ ] 任务复杂度评估
- [ ] 进度记录机制 ⭐
- [ ] 文档摘要规范 ⭐
- [ ] AI_RULES 生成计划 ⭐
- [ ] 交互策略
- [ ] 文档生成计划
- [ ] 质量保证措施

**内容完整性检查**:
- [ ] 进度记录机制包含: generation_progress.md, PROGRESS_TEMPLATE.md
- [ ] 文档摘要规范包含: YAML Frontmatter, SUMMARY_FORMAT_SPEC.md
- [ ] AI_RULES生成计划包含: ai_rules.md, AI_RULES_TEMPLATE.md

### 主文档 (AI_Coding_Context.md)

**必需章节** (16个):
- [ ] YAML Frontmatter 摘要
- [ ] 文档定位说明
- [ ] 项目概览
- [ ] 关键目录速查
- [ ] 场景快速导航
- [ ] 文档索引
- [ ] 设计思维引导
- [ ] 开发流程规范
- [ ] AI 角色库
- [ ] 知识库使用说明
- [ ] 核心代码模式
- [ ] 命名规范
- [ ] 业务模块映射
- [ ] 文档维护触发器 ⭐
- [ ] AI 编码禁忌 ⭐
- [ ] 常见任务速查 ⭐

### 其他必需文件

- [ ] `dev_docs/_analysis/generation_progress.md` - 进度文件
- [ ] `ai_rules.md` - AI规则文件（项目根目录）

### 子文档质量

- [ ] 所有子文档包含YAML Frontmatter摘要
- [ ] 所有摘要包含7个必需字段

---

## 💻 核心代码结构

### 审核编排器

```python
# tools/py/post_generation_audit.py

class PostGenerationAuditor:
    def __init__(self, docs_path: str):
        self.docs_path = docs_path
        self.results = {}
        
    def run_audit(self):
        """运行完整审核"""
        print("🔍 开始文档体系审核...")
        
        # 1. 审核方案文档
        self.results['plan'] = self.audit_generation_plan()
        
        # 2. 审核主文档
        self.results['main_doc'] = self.audit_main_doc()
        
        # 3. 审核进度文件
        self.results['progress'] = self.audit_progress_file()
        
        # 4. 审核AI_RULES文件
        self.results['ai_rules'] = self.audit_ai_rules()
        
        # 5. 审核子文档
        self.results['sub_docs'] = self.audit_sub_docs()
        
        # 6. 生成报告
        report = self.generate_report()
        
        return report
```

### 方案文档审核器

```python
# tools/py/audit_generation_plan.py

REQUIRED_SECTIONS = [
    "任务复杂度评估",
    "进度记录机制",
    "文档摘要规范",
    "AI_RULES 生成计划",
    "交互策略",
    "文档生成计划",
    "质量保证措施"
]

def audit_generation_plan(plan_file: str) -> dict:
    """审核方案文档"""
    content = read_file(plan_file)
    
    results = {
        'score': 0,
        'missing_sections': [],
        'incomplete_sections': [],
        'warnings': []
    }
    
    # 检查必需章节
    for section in REQUIRED_SECTIONS:
        if section not in content:
            results['missing_sections'].append(section)
    
    # 检查内容完整性
    if '进度记录机制' in content:
        if 'generation_progress.md' not in content:
            results['incomplete_sections'].append('进度记录机制')
    
    # 计算评分
    results['score'] = calculate_score(results)
    
    return results
```

---

## 🔗 关键上下文

### 1. 审核实践案例

**位置**: `dev/real_case/002/quality_review/`

**关键文档**:
- `COMPREHENSIVE_AUDIT.md` - 完整的审核方法和发现
- `MAIN_DOC_AUDIT.md` - 主文档审核示例
- `DEFECT_ANALYSIS.md` - 根因分析

**学习要点**:
- 如何识别遗漏项
- 如何分级问题
- 如何提供改进建议

### 2. 框架模板

**位置**: `templates/`

**关键模板**:
- `AI_Coding_Context_TEMPLATE.md` - 主文档模板
- `GENERATION_PLAN_TEMPLATE.md` - 方案文档模板
- `AI_RULES_TEMPLATE.md` - AI规则模板

**学习要点**:
- 模板的必需章节
- 章节的内容要求
- 质量标准

### 3. 现有工具

**位置**: `tools/py/`

**可参考工具**:
- `summary_validator.py` - 摘要验证工具
- `project_scanner.py` - 项目扫描工具

**学习要点**:
- 工具的代码结构
- 错误处理方式
- 输出格式

---

## ✅ 开发检查清单

### 开始开发前

- [ ] 阅读 `requirements.md` 了解完整需求
- [ ] 阅读 `dev/real_case/002/quality_review/` 了解审核实践
- [ ] 阅读 `templates/` 了解模板要求
- [ ] 阅读 `tools/py/summary_validator.py` 了解现有工具

### 开发过程中

- [ ] 创建所有必需的工具文件
- [ ] 实现所有审核功能
- [ ] 编写单元测试
- [ ] 使用002案例测试

### 开发完成后

- [ ] 所有测试通过
- [ ] 使用002案例验证能检测出所有遗漏项
- [ ] 更新工作流文档
- [ ] 更新工具文档
- [ ] 编写使用文档

---

## 🚀 立即开始

### Step 1: 阅读需求文档

```bash
# 阅读完整需求
cat .kiro/specs/post-generation-audit/requirements.md
```

### Step 2: 阅读审核实践案例

```bash
# 阅读全面核查报告
cat dev/real_case/002/quality_review/COMPREHENSIVE_AUDIT.md

# 阅读主文档评估
cat dev/real_case/002/quality_review/MAIN_DOC_AUDIT.md
```

### Step 3: 开始开发

```bash
# 创建第一个工具
touch tools/py/post_generation_audit.py

# 开始编码
# ...
```

---

## 📞 需要帮助？

如果在开发过程中遇到问题：

1. **查看审核实践案例** - `dev/real_case/002/quality_review/`
2. **查看框架模板** - `templates/`
3. **查看现有工具** - `tools/py/`
4. **查看工作流文档** - `workflows/path_a_first_generation.md`

---

**文档版本**: v1.0  
**最后更新**: 2025-12-19  
**准备好了吗？开始开发吧！** 🚀
